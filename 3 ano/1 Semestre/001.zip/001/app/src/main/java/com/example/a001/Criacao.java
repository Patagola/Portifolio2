package com.example.a001;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class Criacao extends AppCompatActivity {
    EditText novoLogin, novaSenha, corfimacao;
    static ArrayList<Usuario> Listinha;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_criacao);
        getSupportActionBar().hide();
        novoLogin = findViewById(R.id.login);
        novaSenha = findViewById(R.id.senhas);
        corfimacao = findViewById(R.id.confimarsenha);
    }
    public void criacao(View v){
        String login = novoLogin.getText().toString();
        String senha = novaSenha.getText().toString();
        String conf = corfimacao.getText().toString();
        if (senha.equals(conf)){
            Usuario u = new Usuario(login,senha, false);
        }
        else{
            Toast.makeText(this, "Errou!!!", Toast.LENGTH_SHORT).show();
        }
        Intent i = new Intent(this, Criacao.class);
        startActivity(i);
        Criacao.Listinha = Listinha;
        //feito por Diego

    }

}