package com.example.a001;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class Admin extends AppCompatActivity {
    static ArrayList<Usuario> Listinha;
    EditText buscaLogin;
    TextView resultado;
    Usuario encontrado = new Usuario();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        getSupportActionBar().hide();
        buscaLogin = findViewById(R.id.buscar);
         resultado = findViewById(R.id.resultado);

    }
    public void buscar (View view){
        String login = buscaLogin.getText().toString();
        String mensagem = "Login" +login+ "não encontrado!";
        for(Usuario u : Listinha){
            if(u.login.equals(login)){
                mensagem = "Login"+login+"Encontrados";
                encontrado = u;
                break;
            }
        }
        resultado.setText(mensagem);
    }
}