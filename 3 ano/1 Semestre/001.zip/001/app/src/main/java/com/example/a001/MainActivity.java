package com.example.a001;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText campo, login, senha;
    ArrayList<Usuario>Listinha = new ArrayList<>();
    private MainActivity cadastro ;static ArrayList<Usuario>tro;

    @Override
    protected void onCreate(Bundle savedInstanceState) { //Primeiro metodo da activity a ser execultado
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();//Obter o banner com o titulo do app e esconder
        campo = findViewById(R.id.Escreva);//Vincular variavel do java com xnl
        login = findViewById(R.id.login);
        senha = findViewById(R.id.senhas);
        criaUsuario();
    }
    public void clicar(View v){//O view torna visivel ao arquivo xnl
        String Mensagem = "oi,"+campo.getText()+",Galo cego te ama";
        Toast.makeText(this,Mensagem, Toast.LENGTH_SHORT).show();
    }
    public void logar(View v){
        String user = login.getText().toString();
        String pass = senha.getText().toString();
        String mensagem = "Bem vindo!";
        for (Usuario u:Listinha){
            if (user.equals(u.getLogin()) && pass.equals(u.getSenha())){
              if (u.isAdmin()){
                  Intent i = new Intent(this,Admin.class);
                  startActivity(i);
                  Admin.Listinha = Listinha;
              }
              else {
                Intent i = new Intent(this,Comum.class);
                startActivity(i);
            }
              break;
       }
        else {
            mensagem = "Errou!";
        }
    }
    Toast.makeText(this, mensagem, Toast.LENGTH_LONG).show();

    }

    private void criaUsuario() {
        Usuario p1 = new Usuario("admin",  "admin",  true);
        Usuario p2 = new Usuario("sakura",  "sasa",  true);
        Usuario p3 = new Usuario("manoel",  "azul",  false);
        Usuario p4 = new Usuario("ednaldo", "deus", false);
        Usuario p5 = new Usuario("felipe",  "quatro", false);

        Listinha.add(p1);
        Listinha.add(p2);
        Listinha.add(p3);
        Listinha.add(p4);
        Listinha.add(p5);
    }
    public void cadastro(View v){
        Intent i = new Intent(this, Criacao.class);
        startActivity(i);
        cadastro.Listinha = Listinha;
    }

}